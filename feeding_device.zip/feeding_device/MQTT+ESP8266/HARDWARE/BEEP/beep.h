#ifndef __BEEP_H
#define __BEEP_H
#include "sys.h"

void Beep_init(void);


#endif 
